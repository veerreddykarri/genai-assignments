/**
 * Collection of default prompts for different use cases (ICE POT Format)
 */
export const DEFAULT_PROMPTS = {
 
  /**
   * Selenium Java Page Object Prompt (No Test Class)
   */
  SELENIUM_JAVA_PAGE_ONLY: `
    Instructions:
    - Generate ONLY a Selenium Java Page Object Class (no test code).
    - Add JavaDoc for methods & class.
    - Use Selenium 2.30+ compatible imports.
    - Use meaningful method names.
    - Do NOT include explanations or test code.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`java
    package com.testleaf.pages;

    /**
     * Page Object for Component Page
     */
    public class ComponentPage {
        // Add methods as per the DOM
    }
    \`\`\`

    Persona:
    - Audience: Automation engineer focusing on maintainable POM structure.

    Output Format:
    - A single Java class inside a \`\`\`java\`\`\` block.

    Tone:
    - Clean, maintainable, enterprise-ready.
  `,

  /**
   * Playwright TypeScript Page Object Prompt (No Test Class)
   */
  PLAYWRIGHT_TYPESCRIPT_PAGE_ONLY: `
    Instructions:
    - Generate ONLY a Playwright TypeScript Page Object Class (no test code).
    - Use @playwright/test imports: Page, Locator, and expect only when needed inside page methods.
    - Use readonly Locator fields for important elements from the DOM.
    - Prefer resilient Playwright locators in this order: getByRole, getByLabel, getByPlaceholder, getByText, then CSS only when needed.
    - Add TSDoc comments for class and methods.
    - Use meaningful method names.
    - Include a constructor that accepts Page.
    - Add async action methods for the user flows represented by the DOM.
    - Use await with every Playwright action.
    - Do NOT include explanations or test code.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`ts
    import { Locator, Page } from '@playwright/test';

    /**
     * Page object for the login page.
     */
    export class LoginPage {
      readonly page: Page;
      readonly usernameInput: Locator;
      readonly passwordInput: Locator;
      readonly loginButton: Locator;

      constructor(page: Page) {
        this.page = page;
        this.usernameInput = page.getByLabel('Username');
        this.passwordInput = page.getByLabel('Password');
        this.loginButton = page.getByRole('button', { name: 'Login' });
      }

      /**
       * Enters the username.
       */
      async enterUsername(username: string) {
        await this.usernameInput.fill(username);
      }

      /**
       * Enters the password.
       */
      async enterPassword(password: string) {
        await this.passwordInput.fill(password);
      }

      /**
       * Submits the login form.
       */
      async clickLogin() {
        await this.loginButton.click();
      }
    }
    \`\`\`

    Persona:
    - Audience: Automation engineers building maintainable Playwright page objects.

    Output Format:
    - A single TypeScript class inside a \`\`\`ts\`\`\` block.

    Tone:
    - Clean, maintainable, enterprise-ready.
  `,

  /**
   * Playwright TypeScript Cucumber Feature File Prompt
   */
  PLAYWRIGHT_TYPESCRIPT_WITH_CUCUMBER: `
    Instructions:
    - Generate ONLY a Cucumber (.feature) file suitable for Playwright TypeScript automation.
    - Use Scenario Outline with Examples table.
    - Make sure every step is relevant to the provided DOM.
    - Do not combine multiple actions into one step.
    - Use South India realistic dataset (names, addresses, pin codes, mobile numbers).
    - Use dropdown values only from provided DOM.
    - Generate multiple scenarios if applicable.
    - Use clear Given/When/Then wording that can be implemented with Playwright.
    - Do NOT include step definition code, page object code, explanations, or comments.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps

    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I type "<username>" into the Username field
      And I type "<password>" into the Password field
      And I click the Login button
      Then I should be logged in successfully

    Examples:
      | username   | password  |
      | "testuser" | "testpass"|
      | "admin"    | "admin123"|
    \`\`\`

    Persona:
    - Audience: BDD testers using Playwright with TypeScript.

    Output Format:
    - Only valid Gherkin in a \`\`\`gherkin\`\`\` block.

    Tone:
    - Clear, structured, executable.
  `,

  /**
   * Cucumber with Playwright TypeScript Step Definitions
   */
  CUCUMBER_WITH_PLAYWRIGHT_TYPESCRIPT_STEPS: `
    Instructions:
    - Generate BOTH:
      1. A Cucumber .feature file.
      2. A TypeScript step definition file using Playwright.
    - Do NOT include Page Object code.
    - Step definitions must include Playwright setup, explicit waits/assertions, and actual Playwright TypeScript syntax.
    - Use @cucumber/cucumber imports for Given, When, Then, Before, and After.
    - Use Playwright imports from @playwright/test.
    - Prefer resilient Playwright locators in this order: getByRole, getByLabel, getByPlaceholder, getByText, then CSS only when needed.
    - Navigate to the provided URL in the opening step.
    - Close the browser in After.
    - Use Scenario Outline with Examples table (South India realistic data).
    - Do NOT include explanations outside the code blocks.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps

    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I type "<username>" into the Username field
      And I type "<password>" into the Password field
      And I click the Login button
      Then I should be logged in successfully

    Examples:
      | username   | password  |
      | "testuser" | "testpass"|
      | "admin"    | "admin123"|
    \`\`\`

    \`\`\`ts
    import { Given, When, Then, Before, After } from '@cucumber/cucumber';
    import { Browser, BrowserContext, chromium, expect, Page } from '@playwright/test';

    let browser: Browser;
    let context: BrowserContext;
    let page: Page;

    Before(async function () {
      browser = await chromium.launch({ headless: true });
      context = await browser.newContext();
      page = await context.newPage();
    });

    After(async function () {
      await browser.close();
    });

    Given('I open the login page', async function () {
      await page.goto('\${pageUrl}');
    });

    When('I type {string} into the Username field', async function (username: string) {
      await page.getByLabel('Username').fill(username);
    });

    When('I type {string} into the Password field', async function (password: string) {
      await page.getByLabel('Password').fill(password);
    });

    When('I click the Login button', async function () {
      await page.getByRole('button', { name: 'Login' }).click();
    });

    Then('I should be logged in successfully', async function () {
      await expect(page.locator('.success')).toBeVisible();
    });
    \`\`\`

    Persona:
    - Audience: QA engineers working with Cucumber & Playwright TypeScript.

    Output Format:
    - Gherkin in \`\`\`gherkin\`\`\` block + TypeScript code in \`\`\`ts\`\`\` block.

    Tone:
    - Professional, executable, structured.
  `,

  /**
   * Playwright BDD package style with Feature, Step Definitions, and Page Object
   */
  PLAYWRIGHT_BDD_TYPESCRIPT_FULL: `
    Instructions:
    - Generate Playwright BDD code using the playwright-bdd package style.
    - Generate exactly THREE outputs:
      1. A Gherkin .feature file.
      2. A TypeScript step definition file using createBdd() from playwright-bdd.
      3. A TypeScript Playwright Page Object class.
    - The feature file should be compatible with playwright-bdd feature mapping through defineBddConfig().
    - The step definition file must import createBdd from playwright-bdd.
    - The step definition file must import expect from @playwright/test only when assertions are needed.
    - The step definition file must instantiate and use the generated page object.
    - Do NOT use @cucumber/cucumber imports.
    - Do NOT manually launch or close the browser; use the Playwright page fixture provided to playwright-bdd steps.
    - Use resilient Playwright locators in the Page Object in this order: getByRole, getByLabel, getByPlaceholder, getByText, then CSS only when needed.
    - Include navigation to the provided URL in a Given step.
    - Use Scenario Outline with Examples table where test data is needed.
    - Use dropdown values only from the provided DOM.
    - Use South India realistic dataset when sample data is needed.
    - Do NOT include generated spec files; playwright-bdd generates/mounts tests from the .feature mapping.
    - Do NOT include explanations outside the code blocks.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps

    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I login with username "<username>" and password "<password>"
      Then I should be logged in successfully

    Examples:
      | username   | password   |
      | demoSales  | crmsfa     |
      | adminUser  | admin123   |
    \`\`\`

    \`\`\`ts
    import { createBdd } from 'playwright-bdd';
    import { expect } from '@playwright/test';
    import { LoginPage } from '../pages/LoginPage';

    const { Given, When, Then } = createBdd();

    Given('I open the login page', async ({ page }) => {
      const loginPage = new LoginPage(page);
      await loginPage.goto();
    });

    When('I login with username {string} and password {string}', async ({ page }, username: string, password: string) => {
      const loginPage = new LoginPage(page);
      await loginPage.login(username, password);
    });

    Then('I should be logged in successfully', async ({ page }) => {
      await expect(page.locator('.success')).toBeVisible();
    });
    \`\`\`

    \`\`\`ts
    import { Locator, Page } from '@playwright/test';

    /**
     * Page object for the login page.
     */
    export class LoginPage {
      readonly page: Page;
      readonly usernameInput: Locator;
      readonly passwordInput: Locator;
      readonly loginButton: Locator;

      constructor(page: Page) {
        this.page = page;
        this.usernameInput = page.getByLabel('Username');
        this.passwordInput = page.getByLabel('Password');
        this.loginButton = page.getByRole('button', { name: 'Login' });
      }

      async goto() {
        await this.page.goto('\${pageUrl}');
      }

      async login(username: string, password: string) {
        await this.usernameInput.fill(username);
        await this.passwordInput.fill(password);
        await this.loginButton.click();
      }
    }
    \`\`\`

    Persona:
    - Audience: QA automation engineers using playwright-bdd with TypeScript.

    Output Format:
    - One \`\`\`gherkin\`\`\` feature block.
    - One \`\`\`ts\`\`\` step definition block.
    - One \`\`\`ts\`\`\` page object block.

    Tone:
    - Practical, maintainable, Playwright-native.
  `,

  /**
   * Serenity BDD with Cucumber, Java Step Definitions, and Page Object
   */
  SERENITY_BDD_JAVA_FULL: `
    Instructions:
    - Generate Serenity BDD code using Java, Selenium, and Cucumber.
    - Generate exactly THREE outputs:
      1. A Gherkin .feature file.
      2. A Java Cucumber step definition class using Serenity BDD.
      3. A Java Serenity Page Object class.
    - The Page Object must extend net.serenitybdd.core.pages.PageObject.
    - Use net.serenitybdd.core.pages.WebElementFacade for page elements when useful.
    - Do not use @Steps for Page Object fields; keep Page Objects as injected Serenity page objects.
    - Keep browser lifecycle management out of the step definitions; Serenity manages the WebDriver lifecycle.
    - Use Cucumber Java imports from io.cucumber.java.en.
    - Use Serenity Page Object methods for browser interactions instead of raw WebDriver in step definitions.
    - Add JavaDoc for classes and important methods.
    - Use Scenario Outline with Examples table where test data is needed.
    - Use dropdown values only from the provided DOM.
    - Use South India realistic dataset when sample data is needed.
    - Do NOT include explanations outside the code blocks.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps

    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I login with username "<username>" and password "<password>"
      Then I should be logged in successfully

    Examples:
      | username   | password   |
      | demoSales  | crmsfa     |
      | adminUser  | admin123   |
    \`\`\`

    \`\`\`java
    package starter.stepdefinitions;

    import io.cucumber.java.en.Given;
    import io.cucumber.java.en.Then;
    import io.cucumber.java.en.When;
    import starter.pages.LoginPage;

    /**
     * Step definitions for login scenarios.
     */
    public class LoginStepDefinitions {

        private LoginPage loginPage;

        @Given("I open the login page")
        public void openLoginPage() {
            loginPage.openLoginPage();
        }

        @When("I login with username {string} and password {string}")
        public void loginWithCredentials(String username, String password) {
            loginPage.login(username, password);
        }

        @Then("I should be logged in successfully")
        public void shouldBeLoggedInSuccessfully() {
            loginPage.shouldShowSuccessfulLogin();
        }
    }
    \`\`\`

    \`\`\`java
    package starter.pages;

    import net.serenitybdd.core.pages.PageObject;
    import net.serenitybdd.core.pages.WebElementFacade;
    import org.openqa.selenium.support.FindBy;

    /**
     * Serenity Page Object for the login page.
     */
    public class LoginPage extends PageObject {

        @FindBy(id = "username")
        private WebElementFacade usernameInput;

        @FindBy(id = "password")
        private WebElementFacade passwordInput;

        @FindBy(css = "button[type='submit']")
        private WebElementFacade loginButton;

        /**
         * Opens the login page.
         */
        public void openLoginPage() {
            openAt("\${pageUrl}");
        }

        /**
         * Logs in with the supplied credentials.
         */
        public void login(String username, String password) {
            usernameInput.type(username);
            passwordInput.type(password);
            loginButton.click();
        }

        /**
         * Verifies successful login.
         */
        public void shouldShowSuccessfulLogin() {
            $(".success").shouldBeVisible();
        }
    }
    \`\`\`

    Persona:
    - Audience: QA automation engineers using Serenity BDD with Cucumber and Java.

    Output Format:
    - One \`\`\`gherkin\`\`\` feature block.
    - One \`\`\`java\`\`\` step definition block.
    - One \`\`\`java\`\`\` Serenity Page Object block.

    Tone:
    - Maintainable, report-friendly, Serenity-native.
  `,

  /**
   * Cucumber Feature File Only Prompt
   */
  CUCUMBER_ONLY: `
    Instructions:
    - Generate ONLY a Cucumber (.feature) file.
    - Use Scenario Outline with Examples table.
    - Make sure every step is relevant to the provided DOM.
    - Do not combine multiple actions into one step.
    - Use South India realistic dataset (names, addresses, pin codes, mobile numbers).
    - Use dropdown values only from provided DOM.
    - Generate multiple scenarios if applicable.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps

    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I type "<username>" into the Username field
      And I type "<password>" into the Password field
      And I click the Login button
      Then I should be logged in successfully

    Examples:
      | username   | password  |
      | "testuser" | "testpass"|
      | "admin"    | "admin123"|
    \`\`\`

    Persona:
    - Audience: BDD testers who only need feature files.

    Output Format:
    - Only valid Gherkin in a \`\`\`gherkin\`\`\` block.

    Tone:
    - Clear, structured, executable.
  `,

  /**
   * Cucumber with Step Definitions
   */
  CUCUMBER_WITH_SELENIUM_JAVA_STEPS: `
    Instructions:
    - Generate BOTH:
      1. A Cucumber .feature file.
      2. A Java step definition class for selenium.
    - Do NOT include Page Object code.
    - Step defs must include WebDriver setup, explicit waits, and actual Selenium code.
    - Use Scenario Outline with Examples table (South India realistic data).

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps

    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I type "<username>" into the Username field
      And I type "<password>" into the Password field
      And I click the Login button
      Then I should be logged in successfully

    Examples:
      | username   | password  |
      | "admin"    | "admin123"|
    \`\`\`

    \`\`\`java
    package com.leaftaps.stepdefs;

    import io.cucumber.java.en.*;
    import org.openqa.selenium.*;
    import org.openqa.selenium.chrome.ChromeDriver;
    import org.openqa.selenium.support.ui.*;

    public class LoginStepDefinitions {
        private WebDriver driver;
        private WebDriverWait wait;

        @io.cucumber.java.Before
        public void setUp() {
            driver = new ChromeDriver();
            wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            driver.manage().window().maximize();
        }

        @io.cucumber.java.After
        public void tearDown() {
            if (driver != null) driver.quit();
        }

        @Given("I open the login page")
        public void openLoginPage() {
            driver.get("\${pageUrl}");
        }

        @When("I type {string} into the Username field")
        public void enterUsername(String username) {
            WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.id("username")));
            el.sendKeys(username);
        }

        @When("I type {string} into the Password field")
        public void enterPassword(String password) {
            WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.id("password")));
            el.sendKeys(password);
        }

        @When("I click the Login button")
        public void clickLogin() {
            driver.findElement(By.xpath("//button[contains(text(),'Login')]")).click();
        }

        @Then("I should be logged in successfully")
        public void verifyLogin() {
            WebElement success = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("success")));
            assert success.isDisplayed();
        }
    }
    \`\`\`

    Persona:
    - Audience: QA engineers working with Cucumber & Selenium.

    Output Format:
    - Gherkin in \`\`\`gherkin\`\`\` block + Java code in \`\`\`java\`\`\` block.

    Tone:
    - Professional, executable, structured.
  `
};

/**
 * Helper function to escape code blocks in prompts
 */
function escapeCodeBlocks(text) {
  return text.replace(/```/g, '\\`\\`\\`');
}

/**
 * Function to fill template variables in a prompt
 */
export function getPrompt(promptKey, variables = {}) {
  let prompt = DEFAULT_PROMPTS[promptKey];
  if (!prompt) {
    throw new Error(`Prompt not found: ${promptKey}`);
  }

  Object.entries(variables).forEach(([k, v]) => {
    const regex = new RegExp(`\\$\\{${k}\\}`, 'g');
    prompt = prompt.replace(regex, v);
  });

  return prompt.trim();
}

export const CODE_GENERATOR_TYPES = {
  SELENIUM_JAVA_PAGE_ONLY: 'Selenium-Java-Page-Only',
  PLAYWRIGHT_TYPESCRIPT_PAGE_ONLY: 'Playwright-TypeScript-Page-Only',
  PLAYWRIGHT_TYPESCRIPT_WITH_CUCUMBER: 'Playwright-TypeScript-With-Cucumber',
  CUCUMBER_WITH_PLAYWRIGHT_TYPESCRIPT_STEPS: 'Cucumber-With-Playwright-TypeScript-Steps',
  PLAYWRIGHT_BDD_TYPESCRIPT_FULL: 'Playwright-BDD-TypeScript-Full',
  SERENITY_BDD_JAVA_FULL: 'Serenity-BDD-Java-Full',
  CUCUMBER_ONLY: 'Cucumber-Only',
  CUCUMBER_WITH_SELENIUM_JAVA_STEPS: 'Cucumber-With-Selenium-Java-Steps',
};
