import { getPrompt } from '../scripts/prompts.js';

// Constants
const INITIAL_SYSTEM_MESSAGE = ``;

function canScriptTab(tab) {
    if (!tab?.id || !tab.url) return false;

    const blockedPrefixes = [
        'chrome://',
        'chrome-extension://',
        'edge://',
        'about:',
        'file://'
    ];

    if (blockedPrefixes.some(prefix => tab.url.startsWith(prefix))) {
        return false;
    }

    try {
        const { hostname } = new URL(tab.url);
        return ![
            'chrome.google.com',
            'chromewebstore.google.com'
        ].includes(hostname);
    } catch {
        return false;
    }
}

class ChatUI {
    constructor() {
        // Grab references
        this.messagesContainer     = document.getElementById('chatMessages');
        this.inputField            = document.getElementById('chatInput');
        this.sendButton            = document.getElementById('sendMessage');
        this.inspectorButton       = document.getElementById('inspectorButton');
        this.resetButton           = document.getElementById('resetChat');
        this.runTestButton         = document.getElementById('runTestButton');
        this.pushAndRunButton      = document.getElementById('pushAndRunButton');

        // Language / Browser dropdown

        // Language / Browser dropdown
        this.languageBindingSelect = document.getElementById('languageBinding');
        this.browserEngineSelect   = document.getElementById('browserEngine');
        this.generationModeHint    = document.getElementById('generationModeHint');
        this.supportedComboHint    = document.getElementById('supportedComboHint');
        this.workflowSummary       = document.getElementById('workflowSummary');
        this.domStatus             = document.getElementById('domStatus');

        // Additional states
        this.selectedDomContent    = null;
        this.isInspecting          = false;
        this.markdownReady         = false;
        this.codeGeneratorType     = 'SELENIUM_JAVA_PAGE_ONLY'; // default 
        this.tokenWarningThreshold = 10000;
        this.selectedModel         = '';
        this.selectedProvider      = '';
        this.generatedCode         = '';

        // Clear existing messages + add initial system message
        this.messagesContainer.innerHTML = `
            <div class="loading-container">
                <div class="loading-spinner"></div>
            </div>
        `;
        this.addMessage(INITIAL_SYSTEM_MESSAGE, 'system');

        // Initialize everything
        this.initialize();
        this.initializeMarkdown();
        this.initializeTokenThreshold();
        this.initializeCodeGeneratorType();
    }

    initialize() {
        // Reset chat
        if (this.resetButton) {
            this.resetButton.addEventListener('click', () => {
                this.messagesContainer.innerHTML = '';
                this.addMessage(INITIAL_SYSTEM_MESSAGE, 'system');
                this.selectedDomContent = null;
                this.generatedCode = '';
                this.inspectorButton.classList.remove('has-content','active');
                this.inspectorButton.innerHTML = `
                    <i class="fas fa-mouse-pointer"></i>
                    <span>Inspect</span>
                `;
                this.isInspecting = false;
                this.updateWorkflowStatus();
                
                // Hide all action buttons
                if (this.runTestButton) this.runTestButton.style.display = 'none';
            });
        }

        // Load stored keys
        chrome.storage.sync.get(
          ['groqApiKey','openaiApiKey','testleafApiKey','selectedModel','selectedProvider'],
          (result) => {
            if (result.groqApiKey)   this.groqAPI   = new GroqAPI(result.groqApiKey);
            if (result.openaiApiKey) this.openaiAPI = new OpenAIAPI(result.openaiApiKey);
            if (result.testleafApiKey) this.testleafAPI = new TestleafAPI(result.testleafApiKey);

            this.selectedModel    = result.selectedModel    || '';
            this.selectedProvider = result.selectedProvider || '';
        });

        // Listen for changes
        chrome.storage.onChanged.addListener((changes) => {
            if (changes.groqApiKey)       this.groqAPI   = new GroqAPI(changes.groqApiKey.newValue);
            if (changes.openaiApiKey)     this.openaiAPI = new OpenAIAPI(changes.openaiApiKey.newValue);
            if (changes.testleafApiKey)   this.testleafAPI = new TestleafAPI(changes.testleafApiKey.newValue);
            if (changes.selectedModel)    this.selectedModel = changes.selectedModel.newValue;
            if (changes.selectedProvider) this.selectedProvider = changes.selectedProvider.newValue;
        });

        // Listen for SELECTED_DOM_CONTENT from content.js
        chrome.runtime.onMessage.addListener((msg) => {
            if (msg.type === 'SELECTED_DOM_CONTENT') {
                this.selectedDomContent = msg.content;
                this.inspectorButton.classList.add('has-content');
                this.updateWorkflowStatus();
            }
        });

        // Send button
        this.sendButton.addEventListener('click', () => this.sendMessage());
        this.inputField.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        // Inspector button
        this.inspectorButton.addEventListener('click', async () => {
            try {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                if (!canScriptTab(tab)) {
                    return;
                }
                try {
                    await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        files: ['src/content/content.js']
                    });
                } catch (error) {
                    if (
                        !error.message.includes('already been injected') &&
                        !error.message.includes('cannot be scripted')
                    ) {
                        throw error;
                    }
                }
                const port = chrome.tabs.connect(tab.id);
                port.postMessage({ type: 'TOGGLE_INSPECTOR', reset: true });
                this.isInspecting = !this.isInspecting;
                this.updateInspectorButtonState();
            } catch (error) {
                console.error('Inspector error:', error);
                this.addMessage('Failed to activate inspector. Please refresh and try again.', 'system');
                this.isInspecting = false;
                this.updateInspectorButtonState();
            }
        });

        // Run Test button
        if (this.runTestButton) {
            this.runTestButton.addEventListener('click', () => this.runCucumberTest());
        }

        this.initializeGeneratorControls();

    }

    // ===================
    // Markdown / Parsing
    // ===================
    initializeMarkdown() {
        const checkLibraries = setInterval(() => {
            if (window.marked && window.Prism) {
                
                window.marked.setOptions({
                    highlight: (code, lang) => {
                        // Normalize language name
                        let normalizedLang = lang?.toLowerCase().trim();
                        
                        // Map common language aliases
                        const languageMap = {
                            'feature': 'gherkin',
                            'cucumber': 'gherkin',
                            'bdd': 'gherkin'
                        };
                        
                        if (languageMap[normalizedLang]) {
                            normalizedLang = languageMap[normalizedLang];
                        }
                        
                        if (normalizedLang && Prism.languages[normalizedLang]) {
                            try {
                                return Prism.highlight(code, Prism.languages[normalizedLang], normalizedLang);
                            } catch (e) {
                                console.error('Prism highlight error:', e);
                                return code;
                            }
                        }
                        return code;
                    },
                    langPrefix: 'language-',
                    breaks: true,
                    gfm: true
                });
                const renderer = new marked.Renderer();
            renderer.code = (code, language) => {
                console.log('🎨 Rendering code block:', { language, codeLength: code?.length });
                
                if (typeof code === 'object') {
                    if (code.text) {
                        code = code.text;
                    } else if (code.raw) {
                        code = code.raw.replace(/^```[\\w]*\\n/, '').replace(/\\n```$/, '');
                    } else {
                        code = JSON.stringify(code, null, 2);
                    }
                }
                
                // Normalize language name
                let validLanguage = language?.toLowerCase().trim() || 'typescript';
                console.log('Original language:', language, '-> Normalized:', validLanguage);
                
                // Map common language aliases
                const languageMap = {
                    'feature': 'gherkin',
                    'cucumber': 'gherkin',
                    'bdd': 'gherkin',
                    'js': 'javascript',
                    'ts': 'typescript',
                    'py': 'python',
                    'cs': 'csharp'
                };
                
                if (languageMap[validLanguage]) {
                    console.log('Language mapped:', validLanguage, '->', languageMap[validLanguage]);
                    validLanguage = languageMap[validLanguage];
                }
                
                let highlighted = code;
                
                // Check if Prism language is available
                if (validLanguage && Prism.languages[validLanguage]) {
                    try {
                        console.log('Highlighting with Prism for language:', validLanguage);
                        highlighted = Prism.highlight(code, Prism.languages[validLanguage], validLanguage);
                        console.log('✅ Highlighting successful');
                    } catch (e) {
                        console.error('❌ Highlighting failed for', validLanguage, ':', e);
                        highlighted = code;
                    }
                } else {
                    console.warn('⚠️ Language not supported by Prism:', validLanguage);
                }
                
                const result = `<pre class=\"language-${validLanguage}\"><code class=\"language-${validLanguage}\">${highlighted}</code></pre>`;
                console.log('Final HTML classes:', `language-${validLanguage}`);
                return result;
            };
                window.marked.setOptions({ renderer });
                this.markdownReady = true;
                clearInterval(checkLibraries);
            }
        }, 100);
    }



    parseMarkdown(content) {
        if (!this.markdownReady) {
            return `<pre>${content}</pre>`;
        }
        let textContent;
        if (typeof content === 'string') {
            const match = content.match(/^```(\w+)/);
            textContent = content.replace(/^```\w+/, '```');
        } else if (typeof content === 'object') {
            textContent = content.content || 
                         content.message?.content ||
                         content.choices?.[0]?.message?.content ||
                         JSON.stringify(content, null, 2);
        } else {
            textContent = String(content);
        }
        let processedContent = textContent
            .replace(/&#x60;/g, '`')
            .replace(/&grave;/g, '`')
            .replace(/\\n/g, '\n')
            .replace(/\\"/g, '"')
            .replace(/```(\w*)/g, '\n```$1\n')
            .replace(/```\s*$/g, '\n```\n')
            .replace(/\n{3,}/g, '\n\n');
            try {
                const renderer = new marked.Renderer();
                renderer.code = (code, language) => {
                if (typeof code === 'object') {
                    if (code.text) {
                        code = code.text;
                    } else if (code.raw) {
                        code = code.raw.replace(/^```[\w]*\n/, '').replace(/\n```$/, '');
                    } else {
                        code = JSON.stringify(code, null, 2);
                    }
                }
                const validLanguage = language?.toLowerCase().trim() || 'typescript';
                let highlighted = code;
                if (validLanguage && Prism.languages[validLanguage]) {
                    try {
                        highlighted = Prism.highlight(code, Prism.languages[validLanguage], validLanguage);
                    } catch (e) {
                        console.error('Highlighting failed:', e);
                    }
                }
                return `<pre class="language-${validLanguage}"><code class="language-${validLanguage}">${highlighted}</code></pre>`;
            };
            window.marked.setOptions({ renderer });
            const parsed = window.marked.parse(processedContent);
            
            // Apply syntax highlighting after DOM is updated
            setTimeout(() => {
                const codeBlocks = document.querySelectorAll('pre code[class*="language-"]');
                console.log('📝 Post-parse highlighting for', codeBlocks.length, 'code blocks');
                
                codeBlocks.forEach((block, index) => {
                    // Standard Prism highlighting for all languages
                    try {
                        Prism.highlightElement(block);
                    } catch (e) {
                        console.error('Prism highlighting error:', e);
                    }
                });
            }, 100);
            
            return parsed;
        } catch (error) {
            console.error('Markdown parsing error:', error);
            return `<pre>${textContent}</pre>`;
        }
    }

    async copyTextToClipboard(text) {
        if (navigator.clipboard?.writeText) {
            await navigator.clipboard.writeText(text);
            return;
        }

        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.setAttribute('readonly', '');
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        textarea.remove();
    }

    attachCodeBlockCopyButtons(container) {
        const codeBlocks = container.querySelectorAll('pre code');

        codeBlocks.forEach((codeBlock) => {
            const pre = codeBlock.closest('pre');
            if (!pre || pre.parentElement?.classList.contains('code-block-shell')) return;

            const shell = document.createElement('div');
            shell.className = 'code-block-shell';
            pre.parentNode.insertBefore(shell, pre);
            shell.appendChild(pre);

            const copyButton = document.createElement('button');
            copyButton.type = 'button';
            copyButton.className = 'code-copy-button';
            copyButton.innerHTML = '<i class="fas fa-copy"></i><span>Copy</span>';

            copyButton.addEventListener('click', async () => {
                try {
                    await this.copyTextToClipboard(codeBlock.textContent.trim());
                    copyButton.innerHTML = '<i class="fas fa-check"></i><span>Copied</span>';
                } catch (err) {
                    console.error('Code block copy failed:', err);
                    copyButton.innerHTML = '<i class="fas fa-times"></i><span>Failed</span>';
                }

                setTimeout(() => {
                    copyButton.innerHTML = '<i class="fas fa-copy"></i><span>Copy</span>';
                }, 1800);
            });

            shell.appendChild(copyButton);
        });
    }



    // =============
    // Send Message
    // =============
    async sendMessage() {
        const userMsg = this.inputField.value.trim();
        let apiRef = null;
        this.isInspecting = false;
        this.updateInspectorButtonState();
      
        if (this.selectedProvider === 'groq') apiRef = this.groqAPI;
        else if (this.selectedProvider === 'openai') apiRef = this.openaiAPI;
        else apiRef = this.testleafAPI;
        if (!apiRef) {
          this.addMessage(`Please set your ${this.selectedProvider} API key in the Settings tab.`, 'system');
          return;
        }

        if (!this.selectedDomContent) {
            this.addMessage('Please select some DOM on the page first.', 'system');
            return;
        }

        // --- Retain only 3 <option> elements in <select> tags to simulate real data ---
        function stripExtraOptions(selectElement) {
            const options = selectElement.querySelectorAll('option');
            if (options.length > 3) {
                for (let i = 3; i < options.length; i++) {
                    options[i].remove();
                }
            }
        }

        let domContentProcessed = this.selectedDomContent;
        if (typeof domContentProcessed === 'string') {
            // Parse string to DOM
            const parser = new DOMParser();
            const doc = parser.parseFromString(domContentProcessed, 'text/html');
            const selects = doc.querySelectorAll('select');
            selects.forEach(stripExtraOptions);
            // Serialize back to string
            domContentProcessed = doc.body.innerHTML;
        } else if (domContentProcessed instanceof HTMLElement) {
            // Directly process if it's an HTMLElement
            const selects = domContentProcessed.querySelectorAll('select');
            selects.forEach(stripExtraOptions);
        }

        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const pageUrl = tab?.url || 'unknown';
            const lang = this.languageBindingSelect.value;
            const eng = this.browserEngineSelect.value;
            const promptKeys = this.getPromptKeys(lang, eng);
            if (promptKeys.length === 0) {
                return;
            }

            const finalSnippet = typeof domContentProcessed === 'string'
                ? domContentProcessed
                : JSON.stringify(domContentProcessed, null, 2);

            this.sendButton.disabled = true;
            this.inputField.disabled = true;
            this.sendButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            this.addMessage(userMsg, 'user');
            this.inputField.value = '';

            let combinedContent = '';
            let totalInputTokens = 0;
            let totalOutputTokens = 0;

            for (const key of promptKeys) {
                const builtPrompt = getPrompt(key, {
                    domContent: finalSnippet,
                    pageUrl: pageUrl,
                    userAction: '',
                });

                const finalPrompt = builtPrompt + " Additional Instructions: " + userMsg;
                const resp = await apiRef.sendMessage(finalPrompt, this.selectedModel);
                const returned = resp?.content || resp;
                combinedContent += returned.trim() + '\n\n';

                totalInputTokens += resp.usage?.input_tokens || 0;
                totalOutputTokens += resp.usage?.output_tokens || 0;
            }

            const loader = this.messagesContainer.querySelector('.loading-indicator.active');
            if (loader) loader.remove();

            this.addMessageWithMetadata(combinedContent.trim(), 'assistant', {
                inputTokens: totalInputTokens,
                outputTokens: totalOutputTokens
            });

            this.selectedDomContent = null;
            this.inspectorButton.classList.remove('has-content','active');
            this.inspectorButton.innerHTML = `
                <i class="fas fa-mouse-pointer"></i>
                <span>Inspect</span>
            `;
            this.isInspecting = false;
            this.updateWorkflowStatus();
            if (tab) {
                try {
                    await chrome.tabs.sendMessage(tab.id, { type: 'CLEAR_SELECTION' });
                } catch (err) {
                    const port = chrome.tabs.connect(tab.id);
                    port.postMessage({ type: 'CLEAR_SELECTION' });
                    port.disconnect();
                }
            }
            this.generatedCode = combinedContent.trim();
        } catch (err) {
            const loader = this.messagesContainer.querySelector('.loading-indicator.active');
            if (loader) loader.remove();
            this.addMessage(`Error: ${err.message}`, 'system');
        } finally {
            this.sendButton.disabled = false;
            this.inputField.disabled = false;
            this.sendButton.innerHTML = 'Generate';
        }
    }
      

    // ==============
    // addMessage UI
    // ==============
    addMessage(content, type) {
        if (!content) return;
        const msgDiv = document.createElement('div');
        msgDiv.className = `chat-message ${type}-message`;
        if (type === 'system') {
            msgDiv.innerHTML = content;
        } else {
            const markdownDiv = document.createElement('div');
            markdownDiv.className = 'markdown-content';
            markdownDiv.innerHTML = this.parseMarkdown(content);
            this.attachCodeBlockCopyButtons(markdownDiv);
            msgDiv.appendChild(markdownDiv);
        }
        this.messagesContainer.appendChild(msgDiv);
        if (type === 'user') {
            const loader = document.createElement('div');
            loader.className = 'loading-indicator';
            const lang = this.languageBindingSelect?.value?.toLowerCase() || '';
            const eng = this.browserEngineSelect?.value?.toLowerCase() || '';
            const genType = this.getGeneratorFamily(lang, eng);
            loader.innerHTML = `
              <div class="loading-spinner"></div>
              <span class="loading-text">Generating ${genType} Code</span>
            `;
            this.messagesContainer.appendChild(loader);
            setTimeout(() => loader.classList.add('active'), 0);
        }
        this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
        const msgCount = this.messagesContainer.querySelectorAll('.chat-message').length;
        if (msgCount > 1 && this.resetButton) {
            this.resetButton.classList.add('visible');
        }
    }

    addMessageWithMetadata(content, type, metadata) {
        if (type !== 'assistant') {
            this.addMessage(content, type);
            return;
        }
        const container = document.createElement('div');
        container.className = 'assistant-message';
        const mdDiv = document.createElement('div');
        mdDiv.className = 'markdown-content';
        mdDiv.innerHTML = this.parseMarkdown(content);
        this.attachCodeBlockCopyButtons(mdDiv);
        container.appendChild(mdDiv);
        const metaContainer = document.createElement('div');
        metaContainer.className = 'message-metadata collapsed';
        const actions = document.createElement('div');
        actions.className = 'message-actions';
        const toggleBtn = document.createElement('button');
        toggleBtn.className = 'metadata-toggle';
        const copyBtn = document.createElement('button');
        copyBtn.className = 'metadata-toggle';
        copyBtn.innerHTML = `<i class="fas fa-copy"></i> Copy all code`;
        copyBtn.onclick = async () => {
            const codeBlocks = mdDiv.querySelectorAll('pre code');
            if (codeBlocks.length === 0) {
                copyBtn.innerHTML = `<i class="fas fa-times"></i> No content found`;
                setTimeout(() => { copyBtn.innerHTML = `<i class="fas fa-copy"></i> Copy all code`; }, 2000);
                return;
            }
            let combinedCode = Array.from(codeBlocks).map(block => block.textContent.trim()).join('\n\n');
            combinedCode = combinedCode.replace(/^```[\w-]*\n/, '').replace(/\n```$/, '');
            try {
                await this.copyTextToClipboard(combinedCode);
                copyBtn.innerHTML = `<i class="fas fa-check"></i> Copied!`;
            } catch (err) {
                console.error('Copy failed:', err);
                copyBtn.innerHTML = `<i class="fas fa-times"></i> Failed to copy`;
            }
            setTimeout(() => { copyBtn.innerHTML = `<i class="fas fa-copy"></i> Copy all code`; }, 2000);
        };
        actions.appendChild(toggleBtn);
        actions.appendChild(copyBtn);
        metaContainer.appendChild(actions);
        const details = document.createElement('div');
        details.className = 'metadata-content';
        details.innerHTML = `
          <div class="metadata-row"><span>Input Tokens:</span><span>${metadata.inputTokens}</span></div>
          <div class="metadata-row"><span>Output Tokens:</span><span>${metadata.outputTokens}</span></div>
        `;
        metaContainer.appendChild(details);
        container.appendChild(metaContainer);
        this.messagesContainer.appendChild(container);
        this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
        if (this.resetButton) {
            this.resetButton.classList.add('visible');
        }
    }
    
    updateInspectorButtonState() {
        if (this.isInspecting) {
            this.inspectorButton.classList.add('active');
            this.inspectorButton.innerHTML = `
                <i class="fas fa-mouse-pointer"></i>
                <span>Stop</span>
            `;
        } else {
            this.inspectorButton.classList.remove('active');
            if (!this.selectedDomContent) {
                this.inspectorButton.classList.remove('has-content');
            }
            this.inspectorButton.innerHTML = `
                <i class="fas fa-mouse-pointer"></i>
                <span>Inspect</span>
            `;
        }
    }

    getPromptKeys(language, engine) {
        const checkboxes = this.getGenerationModeCheckboxes().filter(box => box.checked);
        const promptKeys = [];
        const lang = language?.toLowerCase() || '';
        const eng = engine?.toLowerCase() || '';

        // Extract selected generation modes
        const isFeatureChecked = checkboxes.some(box => box.value === 'FEATURE');
        const isPageChecked = checkboxes.some(box => box.value === 'PAGE');
        const isPlaywrightBddChecked = checkboxes.some(box => box.value === 'PLAYWRIGHT_BDD');
        const isSerenityBddChecked = checkboxes.some(box => box.value === 'SERENITY_BDD');

        if (isPlaywrightBddChecked) {
            if (this.isTypeScriptPlaywright(lang, eng)) {
                promptKeys.push('PLAYWRIGHT_BDD_TYPESCRIPT_FULL');
            } else {
                this.addUnsupportedLanguageMessage(lang, eng);
            }
            return promptKeys;
        }

        if (isSerenityBddChecked) {
            if (this.isJavaSelenium(lang, eng)) {
                promptKeys.push('SERENITY_BDD_JAVA_FULL');
            } else {
                this.addUnsupportedLanguageMessage(lang, eng);
            }
            return promptKeys;
        }

        // Validate that at least one option is selected
        if (!isFeatureChecked && !isPageChecked) {
            console.warn('No generation mode selected. Defaulting to Page Object generation.');
            // Default fallback to page object generation
            if (this.isJavaSelenium(lang, eng)) {
                promptKeys.push('SELENIUM_JAVA_PAGE_ONLY');
            } else if (this.isTypeScriptPlaywright(lang, eng)) {
                promptKeys.push('PLAYWRIGHT_TYPESCRIPT_PAGE_ONLY');
            }
            return promptKeys;
        }

        // Generate appropriate prompt keys based on selections and language/engine combination
        if (isFeatureChecked && isPageChecked) {
            // Both feature and page selected - generate combined output
            if (this.isJavaSelenium(lang, eng)) {
                promptKeys.push('CUCUMBER_WITH_SELENIUM_JAVA_STEPS');
            } else if (this.isTypeScriptPlaywright(lang, eng)) {
                promptKeys.push('CUCUMBER_WITH_PLAYWRIGHT_TYPESCRIPT_STEPS');
            } else {
                this.addUnsupportedLanguageMessage(lang, eng);
            }
        } else if (isFeatureChecked) {
            // Feature file only
            if (this.isTypeScriptPlaywright(lang, eng)) {
                promptKeys.push('PLAYWRIGHT_TYPESCRIPT_WITH_CUCUMBER');
            } else {
                promptKeys.push('CUCUMBER_ONLY');
            }
        } else if (isPageChecked) {
            // Page object only
            if (this.isJavaSelenium(lang, eng)) {
                promptKeys.push('SELENIUM_JAVA_PAGE_ONLY');
            } else if (this.isTypeScriptPlaywright(lang, eng)) {
                promptKeys.push('PLAYWRIGHT_TYPESCRIPT_PAGE_ONLY');
            } else {
                this.addUnsupportedLanguageMessage(lang, eng);
            }
        }

        return promptKeys;
    }

    /**
     * Helper method to check if the combination is Java + Selenium
     */
    isJavaSelenium(language, engine) {
        return language === 'java' && engine === 'selenium';
    }

    isTypeScriptPlaywright(language, engine) {
        return (language === 'ts' || language === 'typescript') && engine === 'playwright';
    }

    isCSharpSelenium(language, engine) {
        return language === 'csharp' && engine === 'selenium';
    }

    isPythonSelenium(language, engine) {
        return language === 'python' && engine === 'selenium';
    }

    // typescript/selenium not supported by the selenium webdriver



    /**
     * Helper method to show unsupported language/engine combination message
     */
    addUnsupportedLanguageMessage(language, engine) {
        const message = `${this.getCombinationLabel(language, engine)} is not supported yet. Supported combinations are Java/Selenium and TypeScript/Playwright.`;
        this.addMessage(message, 'system');
    }

    getGenerationModeCheckboxes() {
        return Array.from(document.querySelectorAll('input[name="generationMode"], input[name="javaGenerationMode"]'));
    }

    getCombinationLabel(language, engine) {
        const languageLabels = {
            java: 'Java',
            ts: 'TypeScript',
            typescript: 'TypeScript',
            py: 'Python',
            python: 'Python',
            csharp: 'C#'
        };
        const engineLabels = {
            selenium: 'Selenium',
            playwright: 'Playwright',
            cypress: 'Cypress',
            puppeteer: 'Puppeteer'
        };
        return `${languageLabels[language] || language}/${engineLabels[engine] || engine}`;
    }

    getGeneratorFamily(language, engine) {
        if (this.isTypeScriptPlaywright(language, engine)) return 'Playwright TypeScript';
        if (this.isJavaSelenium(language, engine)) return 'Selenium Java';
        return this.getCombinationLabel(language, engine);
    }

    initializeGeneratorControls() {
        const controls = [
            this.languageBindingSelect,
            this.browserEngineSelect,
            ...this.getGenerationModeCheckboxes()
        ].filter(Boolean);
        const presetButtons = Array.from(document.querySelectorAll('[data-preset]'));

        controls.forEach(control => {
            control.addEventListener('change', (event) => this.handleGeneratorControlChange(event));
        });

        presetButtons.forEach(button => {
            button.addEventListener('click', () => this.applyPreset(button.dataset.preset));
        });

        this.updateGeneratorControlState();
    }

    applyPreset(preset) {
        const modeByValue = new Map(this.getGenerationModeCheckboxes().map(mode => [mode.value, mode]));

        this.getGenerationModeCheckboxes().forEach(mode => {
            mode.checked = false;
        });

        const setMode = (value, checked = true) => {
            const mode = modeByValue.get(value);
            if (mode) mode.checked = checked;
        };

        if (preset === 'selenium-java') {
            this.languageBindingSelect.value = 'java';
            this.browserEngineSelect.value = 'selenium';
            setMode('FEATURE');
        } else if (preset === 'serenity-bdd') {
            this.languageBindingSelect.value = 'java';
            this.browserEngineSelect.value = 'selenium';
            setMode('SERENITY_BDD');
        } else if (preset === 'playwright-ts') {
            this.languageBindingSelect.value = 'ts';
            this.browserEngineSelect.value = 'playwright';
            setMode('FEATURE');
            setMode('PAGE');
        } else if (preset === 'playwright-bdd') {
            this.languageBindingSelect.value = 'ts';
            this.browserEngineSelect.value = 'playwright';
            setMode('PLAYWRIGHT_BDD');
        }

        this.updateGeneratorControlState();
    }

    handleGeneratorControlChange(event) {
        const target = event.target;
        const generationModeChanged = target?.name === 'generationMode' || target?.name === 'javaGenerationMode';

        if (generationModeChanged && target.checked) {
            this.syncGenerationModeSelection(target);
        }

        this.updateGeneratorControlState();
    }

    syncGenerationModeSelection(selectedMode) {
        const packageModeValues = new Set(['PLAYWRIGHT_BDD', 'SERENITY_BDD']);
        const basicModeValues = new Set(['FEATURE', 'PAGE']);
        const allModes = this.getGenerationModeCheckboxes();

        if (packageModeValues.has(selectedMode.value)) {
            allModes.forEach(mode => {
                if (mode !== selectedMode) {
                    mode.checked = false;
                }
            });
            return;
        }

        if (basicModeValues.has(selectedMode.value)) {
            allModes.forEach(mode => {
                if (packageModeValues.has(mode.value)) {
                    mode.checked = false;
                }
            });
        }
    }

    updateGeneratorControlState() {
        const lang = this.languageBindingSelect?.value?.toLowerCase() || '';
        const eng = this.browserEngineSelect?.value?.toLowerCase() || '';
        const isSupported = this.isJavaSelenium(lang, eng) || this.isTypeScriptPlaywright(lang, eng);
        const isPlaywrightBddSupported = this.isTypeScriptPlaywright(lang, eng);
        const isSerenityBddSupported = this.isJavaSelenium(lang, eng);
        const playwrightBddCheckbox = document.getElementById('playwrightBddMode');
        const serenityBddCheckbox = document.getElementById('serenityBddMode');
        const basicModeCheckboxes = this.getGenerationModeCheckboxes()
            .filter(mode => mode.value === 'FEATURE' || mode.value === 'PAGE');
        const family = this.getGeneratorFamily(lang, eng);

        if (playwrightBddCheckbox) {
            playwrightBddCheckbox.disabled = !isPlaywrightBddSupported;
            if (!isPlaywrightBddSupported) {
                playwrightBddCheckbox.checked = false;
            }
        }

        if (serenityBddCheckbox) {
            serenityBddCheckbox.disabled = !isSerenityBddSupported;
            if (!isSerenityBddSupported) {
                serenityBddCheckbox.checked = false;
            }
        }

        const isPlaywrightBddChecked = Boolean(playwrightBddCheckbox?.checked && isPlaywrightBddSupported);
        const isSerenityBddChecked = Boolean(serenityBddCheckbox?.checked && isSerenityBddSupported);
        const isPackageBddChecked = isPlaywrightBddChecked || isSerenityBddChecked;

        basicModeCheckboxes.forEach(mode => {
            mode.disabled = isPackageBddChecked;
        });

        if (this.supportedComboHint) {
            this.supportedComboHint.textContent = isSupported
                ? `${family} is supported for page object, Cucumber, and BDD package generation.`
                : `${family} is not supported yet. Use Java/Selenium or TypeScript/Playwright.`;
            this.supportedComboHint.classList.toggle('unsupported', !isSupported);
        }

        if (this.generationModeHint) {
            if (isPlaywrightBddChecked) {
                this.generationModeHint.textContent = 'Generating playwright-bdd feature, step definitions, and page object.';
            } else if (isSerenityBddChecked) {
                this.generationModeHint.textContent = 'Generating Serenity BDD feature, step definitions, and page object.';
            } else {
                this.generationModeHint.textContent = `Generating ${family} output.`;
            }
        }

        this.updatePresetState();
        this.updateWorkflowStatus();
    }

    updatePresetState() {
        const presetButtons = Array.from(document.querySelectorAll('[data-preset]'));
        const activePreset = this.getActivePreset();

        presetButtons.forEach(button => {
            button.classList.toggle('active', button.dataset.preset === activePreset);
        });
    }

    getActivePreset() {
        const lang = this.languageBindingSelect?.value?.toLowerCase() || '';
        const eng = this.browserEngineSelect?.value?.toLowerCase() || '';
        const checkedModes = this.getGenerationModeCheckboxes()
            .filter(mode => mode.checked)
            .map(mode => mode.value);

        if (this.isJavaSelenium(lang, eng) && checkedModes.includes('SERENITY_BDD')) return 'serenity-bdd';
        if (this.isTypeScriptPlaywright(lang, eng) && checkedModes.includes('PLAYWRIGHT_BDD')) return 'playwright-bdd';
        if (this.isTypeScriptPlaywright(lang, eng)) return 'playwright-ts';
        if (this.isJavaSelenium(lang, eng)) return 'selenium-java';
        return '';
    }

    getSelectedModeLabel() {
        const checkedModes = this.getGenerationModeCheckboxes()
            .filter(mode => mode.checked)
            .map(mode => mode.value);

        if (checkedModes.includes('PLAYWRIGHT_BDD')) return 'Playwright BDD';
        if (checkedModes.includes('SERENITY_BDD')) return 'Serenity BDD';

        const labels = [];
        if (checkedModes.includes('FEATURE')) labels.push('Feature File');
        if (checkedModes.includes('PAGE')) labels.push('Page Class');

        return labels.length > 0 ? labels.join(' + ') : 'Page Class';
    }

    updateWorkflowStatus() {
        const lang = this.languageBindingSelect?.value?.toLowerCase() || '';
        const eng = this.browserEngineSelect?.value?.toLowerCase() || '';
        const family = this.getGeneratorFamily(lang, eng);
        const modeLabel = this.getSelectedModeLabel();

        if (this.workflowSummary) {
            this.workflowSummary.textContent = `${family} - ${modeLabel}`;
        }

        if (this.domStatus) {
            const hasDom = Boolean(this.selectedDomContent);
            this.domStatus.textContent = hasDom ? 'DOM ready' : 'Inspect DOM';
            this.domStatus.classList.toggle('ready', hasDom);
        }

        if (this.inspectorButton && !this.isInspecting) {
            this.inspectorButton.innerHTML = this.selectedDomContent
                ? '<i class="fas fa-check"></i><span>DOM Selected</span>'
                : '<i class="fas fa-mouse-pointer"></i><span>Inspect</span>';
        }
    }

    async initializeCodeGeneratorType() {
        const { codeGeneratorType } = await chrome.storage.sync.get(['codeGeneratorType']);
        if (codeGeneratorType) {
            this.codeGeneratorType = codeGeneratorType;
            const codeGenDrop = document.getElementById('codeGeneratorType');
            if (codeGenDrop) codeGenDrop.value = this.codeGeneratorType;
        }
    }

    async initializeTokenThreshold() {
        const { tokenWarningThreshold } = await chrome.storage.sync.get(['tokenWarningThreshold']);
        if (tokenWarningThreshold) {
            this.tokenWarningThreshold = tokenWarningThreshold;
        }
        const threshInput = document.getElementById('tokenThreshold');
        if (threshInput) {
            threshInput.value = this.tokenWarningThreshold;
            threshInput.addEventListener('change', async (e) => {
                const val = parseInt(e.target.value,10);
                if (val >= 100) {
                    this.tokenWarningThreshold = val;
                    await chrome.storage.sync.set({ tokenWarningThreshold: val });
                } else {
                    e.target.value = this.tokenWarningThreshold;
                }
            });
        }
    }







    async resetChat() {
        try {
            this.messagesContainer.innerHTML = `
                <div class="loading-container">
                    <div class="loading-spinner"></div>
                </div>
            `;
            this.selectedDomContent = null;
            this.isInspecting       = false;
            this.markdownReady      = false;
            this.inspectorButton.classList.remove('has-content','active');
            this.inspectorButton.innerHTML = `
                <i class="fas fa-mouse-pointer"></i>
                <span>Inspect</span>
            `;
            this.inputField.value = '';
            this.sendButton.disabled = false;
            this.sendButton.textContent = 'Generate';
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            if (canScriptTab(tab)) {
                try {
                    await chrome.tabs.sendMessage(tab.id, { type: 'CLEANUP' });
                } catch (err) {
                    console.log('Cleanup error:', err);
                }
                try {
                    await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        files: ['src/content/content.js']
                    });
                } catch (err) {
                    if (
                        !err.message.includes('already been injected') &&
                        !err.message.includes('cannot be scripted')
                    ) {
                        console.error('Re-inject error:', err);
                    }
                }
            }
            if (this.resetButton) {
                this.resetButton.classList.remove('visible');
            }
            if (this.runTestButton) {
                this.runTestButton.style.display = 'none';
            }
            this.addMessage(INITIAL_SYSTEM_MESSAGE, 'system');
        } catch (err) {
            console.error('Error resetting chat:', err);
            this.addMessage('Error resetting chat. Please close and reopen.', 'system');
        }
    }
}


// Initialize
document.addEventListener('DOMContentLoaded', () => {
    new ChatUI();
});
